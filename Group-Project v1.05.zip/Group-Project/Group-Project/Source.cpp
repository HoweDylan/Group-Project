#include <iostream>
#include <string>
#include <fstream>
using namespace std;

struct Customer {
	string name;
	string address;
	string city;
	string state;
	string zip;
	string phoneNum;
	string balance;
	string lastPayment;
};

void newRecord(Customer customers[], int &size, string fileName);
void searchAndDisplay(Customer customers[], int size);
void searchAndDelete(Customer customers[], int size, string fileName);
void searchAndChange(Customer customers[], int size, string fileName);
void displayAll(Customer customers[], int size);
void menu(Customer customers[], int &size, string fileName);
void initialFile();

int main() {
	initialFile();
	return 0;
}

void initialFile() {
	fstream initialFile;
	string fileName;

	cout << "Which file would you like to open? (If it doesnt exist it will be created): ";
	cin >> fileName;

	initialFile.open(fileName);
	if(initialFile.is_open()) {
		int numLines = 0;
		string tempLine;

		while(getline(initialFile, tempLine))
			numLines++;
		numLines = numLines/8;
		
		Customer *customers = new Customer[numLines];

		initialFile.clear();
		initialFile.seekg(0, ios::beg);

		for (int i = 0; i < 1; i++) {
			initialFile
				>> customers[i].name
				>> customers[i].address
				>> customers[i].city
				>> customers[i].state
				>> customers[i].zip
				>> customers[i].phoneNum
				>> customers[i].balance
				>> customers[i].lastPayment;
			cout << customers[i].phoneNum;
		}

		cout << "All done!" << endl;
		menu(customers, numLines, fileName);
	} else {
		cout << "Error!" << endl;
		main();
	}
}

void menu(Customer customers[], int &size, string fileName) {
	unsigned short int choice;
	cout << "Welcome! Please select an option:" << endl
		<< "1. Create a new record" << endl
		<< "2. Search for a record and display" << endl
		<< "3. Search for a record and delete" << endl
		<< "4. Search for a record and change" << endl
		<< "5. Display the whole file" << endl
		<< "6. Quit" << endl
		<< "Enter a choice: ";
	cin >> choice;

	switch(choice) {
		case(1):
			newRecord(customers, size, fileName);
		case(2):
			searchAndDisplay(customers, size);
		case(3):
			searchAndDelete(customers, size, fileName);
		case(4):
			searchAndChange(customers, size, fileName);
		case(5):
			displayAll(customers, size);
		case(6):
			delete[] customers;
			return;
		default:
			cout << "Incorrect usage, please try again" << endl;
			menu(customers, size, fileName);
	}
}

void newRecord(Customer customers[], int &size, string fileName) {
	cout << "Creating new record.." << endl;
	fstream file;
	file.open(fileName, ios::out | ios::app);

	if(file.is_open()) {
		Customer *newCustomers = new Customer[size+1]; 

		for(int i = 0; i < size; i++) {
			newCustomers[i] = customers[i];
		}

		delete[] customers;
		size += 1;

		cout << "Name: ";
		cin >> newCustomers[size-1].name;
		cout << "Address: ";
		cin >> newCustomers[size-1].address;
		cout << "City: ";
		cin >> newCustomers[size-1].city;
		cout << "State: ";
		cin >> newCustomers[size-1].state;
		cout << "Zip: ";
		cin >> newCustomers[size-1].zip;
		cout << "Phone Number: ";
		cin >> newCustomers[size-1].phoneNum;
		cout << "Balance: ";
		cin >> newCustomers[size-1].balance;
		cout << "Last Payment: ";
		cin >> newCustomers[size-1].lastPayment;
		
		file << newCustomers[size-1].name << ' ' 
			<< newCustomers[size-1].address << ' '
			<< newCustomers[size-1].city << ' '
			<< newCustomers[size-1].state << ' '
			<< newCustomers[size-1].zip << ' '
			<< newCustomers[size-1].phoneNum << ' '
			<< newCustomers[size-1].balance << ' '
			<< newCustomers[size-1].lastPayment << '\n';
		file.close();

		cout << "Success!" << endl;
		menu(newCustomers, size, fileName);
	} else
		menu(customers, size, fileName);
}

void searchAndDisplay(Customer customers[], int size) {

}

void searchAndDelete(Customer customers[], int size, string fileName) {

}

void searchAndChange(Customer customers[], int size, string fileName) {

}

void displayAll(Customer customers[], int size) {

}
